#ifndef __LCD_H
#define __LCD_H

#define FLAG_IRQ 0x01

#include "cmsis_os2.h"

int Init_Th_lcd(void);
osThreadId_t get_id_Th_lcd(void);
#endif
