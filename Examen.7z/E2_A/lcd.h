#ifndef __LCD_H
#define __LCD_H

int Init_Th_lcd(void);

#endif
