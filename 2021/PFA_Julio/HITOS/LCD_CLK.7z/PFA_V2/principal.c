#include "principal.h"

/*----------------------------------------------------------------------------
 *					LCD
 *---------------------------------------------------------------------------*/
MSGQUEUE_OBJ_LCD msg_principal_lcd;
extern osMessageQueueId_t mid_MsgQueue_lcd;


/*----------------------------------------------------------------------------
 *					CLOCK
 *---------------------------------------------------------------------------*/
extern int hours;
extern int minutes;
extern int seconds;


/*----------------------------------------------------------------------------
 *					PRINCIPAL
 *---------------------------------------------------------------------------*/
osThreadId_t tid_Thread_principal;                        // thread id
 
void Thread_principal (void *argument);                   // thread function
 
int Init_Thread_principal (void) {
 
  tid_Thread_principal = osThreadNew(Thread_principal, NULL, NULL);
  if (tid_Thread_principal == NULL)
    return(-1);
  return(0);
}

void Thread_principal (void *argument) {
	set_clock(23,59,50);
  while (1) {
		msg_principal_lcd.init_L1 = 30;
		msg_principal_lcd.init_L2 = 10;
		sprintf(msg_principal_lcd.data_L1, "%02d : %02d : %02d", hours, minutes, seconds);
		sprintf(msg_principal_lcd.data_L2, "12 : 34 : 56");
		osMessageQueuePut(mid_MsgQueue_lcd, &msg_principal_lcd, NULL, 0U);//pongo el mensaje a la cola
		
	}
}

