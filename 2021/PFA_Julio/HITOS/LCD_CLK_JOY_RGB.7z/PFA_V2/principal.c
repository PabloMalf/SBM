#include "principal.h"

/*------------------------------*
 *					LCD
 *------------------------------*/
MSGQUEUE_OBJ_LCD msg_principal_lcd;
extern osMessageQueueId_t mid_MsgQueue_lcd;


/*------------------------------*
 *					CLOCK
 *------------------------------*/
extern int hours;
extern int minutes;
extern int seconds;


/*------------------------------*
 *					JOYSTICK
 *------------------------------*/
MSGQUEUE_OBJ_JOY msg_principal_joy;
extern osMessageQueueId_t mid_MsgQueue_joy;


/*------------------------------*
 *					RGB
 *------------------------------*/
MSGQUEUE_OBJ_RGB msg_principal_rgb;
extern osMessageQueueId_t mid_MsgQueue_rgb;


/*------------------------------*
 *					PRINCIPAL
 *------------------------------*/
osThreadId_t tid_Th_principal;
 
void Th_principal (void *argument);
 
int Init_Th_principal (void) {
  tid_Th_principal = osThreadNew(Th_principal, NULL, NULL);
  if (tid_Th_principal == NULL)
    return(-1);
  return(0);
}

void Th_principal (void *argument) {
	set_clock(23,59,50);
	msg_principal_rgb.estado_rgb = ON;
	msg_principal_rgb.estado_led = OFF;
	osMessageQueuePut(mid_MsgQueue_rgb, &msg_principal_rgb, NULL, 0U);
	msg_principal_lcd.init_L1 = 30;
  while (1) {
		sprintf(msg_principal_lcd.data_L1, "%02d : %02d : %02d", hours, minutes, seconds);
		osMessageQueuePut(mid_MsgQueue_lcd, &msg_principal_lcd, NULL, 0U);
		if(hours == 0 && minutes == 0 && seconds == 0){
			msg_principal_rgb.estado_led = ON;
			osMessageQueuePut(mid_MsgQueue_rgb, &msg_principal_rgb, NULL, 0U);
		}
	}
}

