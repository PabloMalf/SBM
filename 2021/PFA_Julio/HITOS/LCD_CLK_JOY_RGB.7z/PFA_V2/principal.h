#ifndef PRINCIPAL_H
#define PRINCIPAL_H

#include "clock.h"  
#include "lcd.h"
#include "joystick.h"
#include "rgb.h"

int Init_Th_principal (void);

#endif
