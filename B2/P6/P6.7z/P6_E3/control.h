#ifndef CONTROL_H
#define CONTROL_H

int Init_Th_control(void);

#endif
